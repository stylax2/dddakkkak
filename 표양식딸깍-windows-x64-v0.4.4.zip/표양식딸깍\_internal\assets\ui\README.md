# UI 이미지 자산 (assets/ui)

`scripts/build_ui_assets.py`가 생성하는 화면용 PNG입니다. 화면 배율(100~300%)별로 `이름@150.png`처럼 따로 만들고, 앱이 실행 중인 화면 배율에 가까운 파일을 골라 씁니다(100%는 `이름.png`). 이렇게 해서 고해상도 화면에서도 이미지를 늘리지 않아 선명합니다. 직접 수정하지 말고 스크립트를 고친 뒤 다시 생성하세요.
`scripts/build.ps1`이 빌드 때 자동으로 다시 만들고, PyInstaller 스펙이 `assets/ui` 폴더째 배포본에 넣습니다.
파일이 없거나 읽지 못하면 UI는 같은 모양을 캔버스로 직접 그려 대체합니다.

| 파일 | 크기(100% 기준) | 쓰는 곳 |
|---|---|---|
| `logo_32.png` | 32px | 상단 바 로고 (`icon_master_1024.png`에서 생성) |
| `logo_26.png` | 26px | 문서 머리 아바타 안 로고 |
| `hero_128.png` | 128px | 복사 전 미리보기 영역의 대표 이미지 |
| `avatar_ring.png` | 36px | 문서 머리 아바타 그라데이션 링 |
| `story_ring_on.png` | 64px | 선택된 작업 문서 (그라데이션 링) |
| `story_ring_off.png` | 64px | 선택되지 않은 작업 문서 |
| `story_ring_dashed.png` | 64px | 열린 문서가 없을 때 |
| `icon_<이름>.png` | 24px | 아이콘 기본색 (#0C0C0D) |
| `icon_<이름>_off.png` | 24px | 비활성 아이콘 (#C7C7C7) |
| `icon_plus*.png`, `icon_minus*.png` | 14px | 헤더 행 수 −/+ |
| `icon_doc_muted.png`, `icon_refresh_muted.png` | 24px | 회색 보조 아이콘 |

아이콘 이름: copy, undo, trash, refresh, pin, pin_filled, doc, table, close, plus, minus

색: 그라데이션 링 #FFB347 → #F2446E → #9B3FD6, 기본 버튼 #0064E0, 보조 버튼 #EFEFEF
